"""
Neural package for Guardian Decision Capsule

Safe, non-blocking cascade components
"""
